<?php
// Establish your database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "car";

$connection = mysqli_connect($servername, $username, $password, $dbname);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}
// Create table if it doesn't exist
$query = "CREATE TABLE IF NOT EXISTS cars (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    brand VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL
)";

if (mysqli_query($connection, $query)) {
    echo "Table created successfully";
} else {
    echo "Error creating table: " . mysqli_error($connection);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);

    if ($data['action'] === 'add_car') {
        $name = $data['name'];
        $brand = $data['brand'];
        $price = $data['price'];

        $query = "INSERT INTO cars (name, brand, price) VALUES ('$name', '$brand', $price)";
        mysqli_query($connection, $query);
        exit; // Stop further execution after adding the car
    }

    if ($data['action'] === 'delete_car') {
        $id = $data['id'];
        $query = "DELETE FROM cars WHERE id = $id";
        mysqli_query($connection, $query);
        exit; // Stop further execution after deleting the car
    }

    if ($data['action'] === 'update_car') {
        $id = $data['id'];
        $name = $data['name'];
        $brand = $data['brand'];
        $price = $data['price'];

        $query = "UPDATE cars SET name = '$name', brand = '$brand', price = $price WHERE id = $id";
        mysqli_query($connection, $query);
        exit; // Stop further execution after updating the car
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = "SELECT * FROM cars";
    $result = mysqli_query($connection, $query);

    $cars = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $cars[] = $row;
    }

    echo json_encode($cars);
}
?>

function validateForm() {
    var name = document.forms["crudForm"]["name"].value;
    var age = document.forms["crudForm"]["age"].value;
    var address = document.forms["crudForm"]["address"].value;
    var password = document.forms["crudForm"]["password"].value;
    var newPassword = document.forms["crudForm"]["new_password"].value;
    
    if (name.trim() === "") {
        alert("Name must be filled out");
        return false;
    }

    if (age.trim() === "" || isNaN(age)) {
        alert("Age must be a number");
        return false;
    }

    if (address.trim() === "") {
        alert("Address must be filled out");
        return false;
    }

    if (password.length < 6 || !/[A-Z]/.test(password) || !/\d/.test(password)) {
        alert("Password must be at least 6 characters long and contain at least one uppercase letter and one digit");
        return false;
    }

    if (newPassword !== "" && (newPassword.length < 6 || !/[A-Z]/.test(newPassword) || !/\d/.test(newPassword))) {
        alert("New password must be at least 6 characters long and contain at least one uppercase letter and one digit");
        return false;
    }
}

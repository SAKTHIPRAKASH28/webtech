<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mera";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['insert'])) {
        $name = $_POST['name'];
        $age = $_POST['age'];
        $address = $_POST['address'];
        $password = $_POST['password'];

        $sql = "INSERT INTO users (name, age, address, password) VALUES ('$name', '$age', '$address', '$password')";

        if ($conn->query($sql) === TRUE) {
            echo "New record created successfully";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }

    if (isset($_POST['update'])) {
        $update_name = $_POST['update_name'];
        $new_age = $_POST['new_age'];
        $new_address = $_POST['new_address'];
        $new_password = $_POST['new_password'];

        $sql = "UPDATE users SET age='$new_age', address='$new_address', password='$new_password' WHERE name='$update_name'";

        if ($conn->query($sql) === TRUE) {
            echo "Record updated successfully";
        } else {
            echo "Error updating record: " . $conn->error;
        }
    }

    if (isset($_POST['delete'])) {
        $delete_name = $_POST['delete_name'];

        $sql = "DELETE FROM users WHERE name='$delete_name'";

        if ($conn->query($sql) === TRUE) {
            echo "Record deleted successfully";
        } else {
            echo "Error deleting record: " . $conn->error;
        }
    }
}

$conn->close();
?>

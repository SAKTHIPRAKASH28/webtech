var express=require("express");
var cors=require("cors");
var bodyParser=require("body-parser");
var mysql=require('mysql');
var app=express();
app.use(express.json())
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));
var con=mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database:"userd"
});
con.connect(function(err){
    if(err){
        throw err;
    }
    console.log("db started");
});
app.post("/register",(req,res)=>{
    const{name,id,salary}=req.body;
    var sql="insert into php(name,id,salary)values(?,?,?)";
    con.query(sql,[name,id,salary],function(err,result){
        if(err){
            throw err;
        }
        res.json({message:result});
    });
});
app.get("/fetch",(req,res)=>{
    var sql="select * from php";
    con.query(sql,function(err,result){
        if(err){
            throw err;
        }
        res.json(result);
    })
});
app.put("/update/:id",(req,res)=>{
    const{id}=req.params;
    const{name}=req.body;
    var sql="update php set name=? where id=?";
    con.query(sql,[name,id],function(err,result){
        if(err){
            throw err;
        }
        res.json({message:result});
    });
});
app.listen(8080,()=>{
    console.log("server started");
})
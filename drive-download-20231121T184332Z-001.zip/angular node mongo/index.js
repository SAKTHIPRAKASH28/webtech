var express=require("express")
var app=express();
var bodyparser=require("body-parser");
var cors=require("cors")
var mongoose=require("mongoose");

app.use(express.json())
app.use(bodyparser.urlencoded({extended:true}))
app.use(cors());

mongoose.connect("mongodb://127.0.0.1:27017/").then((res)=>{
    console.log("connected");
}).catch((err)=>{
    console.log("err");
})
var userscema=new mongoose.Schema({
    name:String,
    mail:String,
    phone:String,
})
var user=mongoose.model("user",userscema);

app.post("/register",async(req,res)=>{
    try
    { 
        const {name,mail,phone}=req.body;
        const userdata=new user({name,mail,phone});
        await userdata.save();
        res.send("succesfully registered");
    }
    catch(err)
    {
        console.log(err);
        res.send("error");
    }
})

app.get("/fetch",(req,res)=>{
   try
   {
     user.find().then((data)=>{
        res.send(data);
     }).catch((err)=>{
        console.log(err);
     })
   }
   catch(err)
   {
    console.log(err);
   }
})

app.post("/delete", async (req, res) => {
    const { name } = req.body;
    try {
        const deletedUser = await user.findOneAndDelete({ name: name });
        if (deletedUser) {
            console.log(deletedUser);
            res.send("Deleted successfully");
        } else {
            res.send("User not found");
        }
    } catch (err) {
        console.error(err);
        res.send("Error deleting user");
    }
})


app.post("/update", async (req, res) => {
    const { name, mail } = req.body;
    try {
        console.log(name)
        const updatedUser = await user.findOneAndUpdate(
            { name: name },
            { mail: mail },
            { new: true } 
        );
        
        if (updatedUser) {
            console.log(updatedUser);
            res.send("Updated successfully");
        } else {
            res.send("User not found");
        }
    } catch (err) {
        console.error(err);
        res.send("Error updating user");
    }
});

app.listen(3000,()=>{
    console.log("listen 0n 3000");
})
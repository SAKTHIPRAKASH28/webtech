const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
app.use(express.static(__dirname));
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());
app.use(bodyParser.json());
app.use(express.json());
const mongoURI = "mongodb://127.0.0.1:27017/Sanjay";


mongoose.connect(mongoURI)
    .then(() => {
        console.log("MongoDB connected");
        app.listen(3000, () => {
            console.log("Server started on port 3000");
        });
    })
    .catch((err) => {
        console.error("MongoDB connection error:", err);
    });

const custSchema = new mongoose.Schema({
  name: String,
  source: String,
  destination: String,
  seat_no: String,
  cost:String
});

const View = mongoose.model('View', custSchema);


app.post('/bookTicket', async (req, res) => {
  try {
      const { name,source,destination,seat_no ,cost} = req.body; 
      const Userdata = new View({ name, source,destination,seat_no,cost});


      await Userdata.save();

      res.json({ message: "Customer  submitted successfully" });
  } catch (error) {
      console.error("Error:", error);
      res.status(500).json({ error: "Customer submission failed" });
  }
});
app.get('/getBookDetails',async (req,res)=>{
try{
const boookedTickets= await View.find();
res.json(boookedTickets);
}
catch(error){
  console.log(error);
  res.status(500).send("Error retireving the details ");
}
});
app.delete('/deleteTicket/:id', async (req, res) => {
  try {
    const id = req.params.id;
    console.log("Deleting ticket with ID:", id);

  const DelTicket=await View.findByIdAndDelete({_id:id});

    if (!DelTicket) {
      return res.status(404).send("Error: Ticket not found");
    }

    console.log("Ticket deleted successfully");
    res.json({ message: "Ticket deleted successfully" });
  } catch (error) {
    console.error("Error deleting ticket:", error);
    res.status(500).send("Internal Server Error");
  }
});

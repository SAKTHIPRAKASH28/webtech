var app=angular.module('MyApp',[]);
app.controller('MyCtrl',['$scope','busService','$http',function($scope,busService,$http){
     $scope.busList=busService.getList();
     $scope.user=null;
     $scope.BookingConfirmed=false;
     $scope.selectedBus=null;
    
  
   $scope.bookedTickets=[];
  
   function fetchReviews() {
     $http.get("http://localhost:3000/getBookDetails").then((res) => {
         $scope.bookedTickets = res.data;
         console.log($scope.bookedTickets);
     }).catch((err) => {
         console.log(err);
     });
 }

     $scope.login=function() {
       if($scope.username){
        $scope.user={username:$scope.username};
       }
     };
     $scope.viewDetails=function(bus){
        $scope.selectedBus=bus;
     };
     $scope.BookNow=function(){
      
        if($scope.selectedBus!=null){
  
          $http.post("http://localhost:3000/bookTicket", {
               name: $scope.username,
               source: $scope.selectedBus.source,
               destination: $scope.selectedBus.destination,
               seat_no :$scope.seat,
               cost:$scope.selectedBus.cost,
             }).then((res) => {
                fetchReviews();
                 $scope.BookingConfirmed = true;
               console.log(res.data);
             }).catch((err) => {
               console.log(err);
             });
   
        }
      
     };

$scope.removeTicket=function(ticket){
     $http.delete(`http://localhost:3000/deleteTicket/${ticket._id}`)
     .then((res)=>{
      alert("ticket deleted successfully",res.data);
     }).catch((err)=>{
      console.log(err);
     })
};
    
}]);
app.factory('busService',function(){
     var busList=[
     { name: 'Bus A', source: 'City1', destination: 'City2' ,cost:500},
{ name: 'Bus B', source: 'City2', destination: 'City3' ,cost:800},
{ name: 'Bus C', source: 'City1', destination: 'City3' ,cost:459},
     ];
     return {getList:function(){
return busList;
     }
     };
});
app.directive('highlightOnClick', function () {
  return {
      restrict: 'A',
      link: function (scope, element) {
          element.on('click', function () {
              element.css('background-color', 'yellow');
              scope.$on('$destroy', function () {
                  element.off('click');
              });
          });
      }
  };
});
const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const cors = require("cors");
const mongoose = require("mongoose");

app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

mongoose.connect("mongodb://127.0.0.1:27017/your-database-name").then(() => {
    console.log("Connected to MongoDB");
}).catch((err) => {
    console.error("Error connecting to MongoDB:", err);
});

// Define Mongoose Schema and Model for user
const userSchema = new mongoose.Schema({
    name: String,
    mail: String,
    phone: String,
});
const User = mongoose.model("User", userSchema);

// POST endpoint for registering a user
app.post("/register", async (req, res) => {
    try {
        const { name, mail, phone } = req.body;
        const newUser = new User({ name, mail, phone });
        await newUser.save();
        res.send("Successfully registered");
    } catch (err) {
        console.error("Error registering user:", err);
        res.status(500).send("Error registering user");
    }
});

// POST endpoint for updating a user's email by name
app.post("/update", async (req, res) => {
    const { name, mail } = req.body;
    try {
        const updatedUser = await User.findOneAndUpdate(
            { name: name },
            { mail: mail },
            { new: true }
        );

        if (updatedUser) {
            res.send("Updated successfully");
        } else {
            res.status(404).send("User not found");
        }
    } catch (err) {
        console.error("Error updating user:", err);
        res.status(500).send("Error updating user");
    }
});

// POST endpoint for deleting a user by name
app.post("/delete", async (req, res) => {
    const { name } = req.body;
    try {
        const deletedUser = await User.findOneAndDelete({ name: name });
        if (deletedUser) {
            res.send("Deleted successfully");
        } else {
            res.status(404).send("User not found");
        }
    } catch (err) {
        console.error("Error deleting user:", err);
        res.status(500).send("Error deleting user");
    }
});
app.get("/fetch", async (req, res) => {
    try {
        const users = await User.find(); // Retrieve all users from MongoDB
        res.json(users); // Send users as a JSON response
    } catch (err) {
        console.error("Error fetching users:", err);
        res.status(500).send("Error fetching users");
    }
});
app.listen(3000, () => {
    console.log("Server listening on port 3000");
});

// mainApp.js

const calculatorEventModule = require('./event');

// Listen for the 'calculationCompleted' event
calculatorEventModule.calculatorEventEmitter.on('calculationCompleted', (result) => {
    console.log('Calculation completed. Result:', result);
    // Perform additional logic if needed
});

// Show the calculator popup
calculatorEventModule.showCalculatorPopup();

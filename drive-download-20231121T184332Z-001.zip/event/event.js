// calculatorEventModule.js

const EventEmitter = require('events');
const readline = require('readline');

class CalculatorEventEmitter extends EventEmitter {}

const calculatorEventEmitter = new CalculatorEventEmitter();

function showCalculatorPopup() {
    const rl = readline.createInterface({
        input: process.stdin,
        output: process.stdout
    });

    rl.question('Enter the first number: ', (firstNumber) => {
        rl.question('Enter the second number: ', (secondNumber) => {
            rl.question('Choose an operation (+, -, *, /): ', (operation) => {
                // Parse input values to numbers
                const num1 = parseFloat(firstNumber);
                const num2 = parseFloat(secondNumber);

                // Perform the calculation based on the chosen operation
                let result;
                switch (operation) {
                    case '+':
                        result = num1 + num2;
                        break;
                    case '-':
                        result = num1 - num2;
                        break;
                    case '*':
                        result = num1 * num2;
                        break;
                    case '/':
                        result = num1 / num2;
                        break;
                    default:
                        console.log('Invalid operation');
                        rl.close();
                        return;
                }

                console.log(`Result: ${result}`);
                // Emit the 'calculationCompleted' event with the result
                calculatorEventEmitter.emit('calculationCompleted', result);
                rl.close();
            });
        });
    });
}

module.exports = {
    showCalculatorPopup,
    calculatorEventEmitter
};
